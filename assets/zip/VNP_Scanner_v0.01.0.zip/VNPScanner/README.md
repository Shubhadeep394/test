# vnp-scanner
Vehicle Number Plate Scanning Android Application
